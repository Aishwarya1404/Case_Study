#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int main(int argc,char *argv[]) {
	int i;
	for(i=1;i<argc;i++)
	{
		//strtok(argv[i],",");
	printf("  \n %s",strtok(argv[i],","));
	}
	return EXIT_SUCCESS;
}
