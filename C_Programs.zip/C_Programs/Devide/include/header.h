#ifndef HEADER_H_
#define HEADER_H_

int sum(int,int);

#endif
