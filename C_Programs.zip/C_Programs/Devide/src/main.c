#include<stdio.h>
#include"../include/header.h"
int main()
{
	int num1=10,num2=20,result;
	result=sum(num1,num2);
	printf("Sum    :%d",result);
	return 0;
}
