//#include "../include/header.h"


int sum(int num1,int num2)
{
	return num1+num2;
}
