#include<stdio.h>
#include<string.h>
char *copy_string(char *,char *);
void *compare_string(char* ,char*);
char *concate_string(char*,char *);
char *reverse_string(char*);
int main(void)
{
	char str1[50]={"Hello world"};
	char str2[50];

	printf("\n-------------strcpy()--------------");
	copy_string(str1,str2);
	printf("\n Copied string is:%s",str1);


	printf("\n------------strcmp()---------------");
	printf("\nEnter string");
	scanf("%s",str1);
	printf("\nEnter string");
	scanf("%s",str2);
	compare_string(str1,str2);

	printf("\n------------strcat()---------------");
	concate_string(str1,str2);
	printf("\nConcatenated string is:%s",str1);

	printf("\n------------strrev()---------------");
	printf("\nEnter string to reverse");
	scanf("%s",str1);
	reverse_string(str1);
	printf("\nReversed string is:%s",str1);
	return 0;
}

char *copy_string(char *s1,char *s2)
{
	int i;
	for(i=0;s1[i]!='\0';i++)
   {
	s2[i]=s1[i];

   }
	s2[i]='\0';
	return s2;
}
void *compare_string(char *s1,char *s2)
{
	int i=0,j,cnt=1;
	if(s1[i]!=s2[i])
		printf("\nStrings are not equal");
	else
	{
		for(i=1;s1[i]!='\0';i++)
		{
			j=s1[i]-s2[i];
			if(j==0)
			{cnt++;
				continue;
			}
			else
				printf("\nStrings are not equal");
		}
		if(cnt==strlen(s1))
			printf("\nStrings are equal");
    }
}
char *concate_string(char* s1,char *s2)
{
	int i,j;
	for(i=0;i<strlen(s1);i++){}
		for(j=0;s2[j]!='\0';j++)
		{
			s1[i]=s2[j];
			i++;
		}
	return s1;
}
char *reverse_string(char*s1)
{
	int i,j;char c;
	while(s1[i]!='\0')
		i++;
	j=i-1;
	for(i=0;i<j;i++)
	{
		c=s1[j];
		s1[j]=s1[i];
		s1[i]=c;
		j--;
	}
	return s1;
}
